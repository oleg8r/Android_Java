package com.example.googlemap;

import android.app.Activity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.Marker;

public class MapsInfoAdapter implements GoogleMap.InfoWindowAdapter {

    private Activity context;

    public MapsInfoAdapter(Activity context) {
        this.context = context;
    }

    @Override
    public View getInfoWindow(Marker marker) {
        return null;
    }

    @Override
    public View getInfoContents(Marker marker) {
        View view = context.getLayoutInflater().inflate(R.layout.info_window, null);

        ImageView image = view.findViewById(R.id.imageView);

        TextView title = view.findViewById(R.id.textViewTitle);
        TextView subtitle = view.findViewById(R.id.textViewSubTitle);
        TextView location = view.findViewById(R.id.textViewLocation);

        image.setBackgroundResource(R.drawable.index);
        title.setText(marker.getTitle());
        subtitle.setText(marker.getSnippet().substring(0, marker.getSnippet().indexOf("|") - 1));
        location.setText(marker.getSnippet().substring(marker.getSnippet().indexOf("|") + 1));

        return view;
    }
}
