package com.example.midtermq1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class RecyclerActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    List<Car> cars = new ArrayList<>();

    void initCars() {
        cars.add(new Car("Corolla", "Toyota", R.drawable.imagedelete));
        cars.add(new Car("Civic", "Honda", R.drawable.imagedelete));
        cars.add(new Car("PathFinder", "Nissan", R.drawable.imagedelete));
        cars.add(new Car("X6", "BMW", R.drawable.imagedelete));
        cars.add(new Car("A4", "Audi", R.drawable.imagedelete));
        cars.add(new Car("Yukon", "GMC", R.drawable.imagedelete));
        cars.add(new Car("Model 3", "Tesla", R.drawable.imagedelete));
        cars.add(new Car("Kuga", "Ford", R.drawable.imagedelete));
        cars.add(new Car("Santa Fe", "Hyundai", R.drawable.imagedelete));
        cars.add(new Car("E Class", "Mercedes", R.drawable.imagedelete));

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initCars();

        setContentView(R.layout.activity_recycler);

        recyclerView= findViewById(R.id.recyclerView);

        RecyclerAdapter recyclerAdapter = new RecyclerAdapter(this, cars);
        recyclerView.setAdapter(recyclerAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
}