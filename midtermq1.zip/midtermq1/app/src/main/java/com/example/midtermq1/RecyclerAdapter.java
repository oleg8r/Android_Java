package com.example.midtermq1;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;


public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.MyViewHolder> {

    Context context;
    List<Car> cars;

    RecyclerAdapter(Context context, List<Car> cars) {
        this.context = context;
        this.cars = cars;
    }

    @NonNull
    @Override
    public RecyclerAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View convertView= LayoutInflater.from(context).inflate(R.layout.row_layout, parent, false); //convertView is the whole row
        return new MyViewHolder(convertView);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerAdapter.MyViewHolder holder, int position) {
//        holder.positionView.setText(Integer.toString(position + 1));
        holder.modelView.setText(cars.get(position).getModel());
        holder.makeView.setText(cars.get(position).getMake());
        holder.imageView.setBackgroundResource(cars.get(position).getImage());

    }

    @Override
    public int getItemCount() {
        return cars.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder  implements View.OnClickListener {
//        TextView positionView;
        TextView modelView;
        TextView makeView;
        ImageView imageView;

        public MyViewHolder(@NonNull View view) {
            super(view);
//            positionView = view.findViewById(R.id.positionView);
            modelView = view.findViewById(R.id.modelView);
            makeView = view.findViewById(R.id.makeView);
            imageView = view.findViewById(R.id.imageView);

//            positionView.setOnClickListener(this);
//            modelView.setOnClickListener(this);
//            makeView.setOnClickListener(this);
            imageView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int index = getAdapterPosition();
//            if (v.getId() == modelView.getId()) {
//                showDialog(cars.get(index).getModel());
//            }

//            if (v.getId() == positionView.getId()) {
//                showDialog("Serial");
//            }
            if (v.getId() == imageView.getId()) {
                System.out.println(getPosition());
                removeAt(getPosition());
//                showDialog(String.valueOf(v.getId()));
//                showDialog(String.valueOf(imageView.getId()));
            }
//            if (v.getId() == makeView.getId()) {
//                showDialog("Score");
//            }
        }
    }

    void showDialog(String text)
    {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);
        alertDialog.setTitle("Title");
        alertDialog.setMessage("You clicked Car " + text);
        alertDialog.setCancelable(true);
        alertDialog.setNegativeButton("DISMISS", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int arg1) {
                d.cancel();
            };
        });

        alertDialog.create().show();
    }

    void removeAt(int position){
        cars.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position,cars.size());
    }
}
