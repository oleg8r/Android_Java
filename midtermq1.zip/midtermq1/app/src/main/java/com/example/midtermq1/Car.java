package com.example.midtermq1;

public class Car {

    String model;
    String make;
    int imagedelete;

    public Car(String model, String make, int imagedelete) {
        this.model = model;
        this.make = make;
        this.imagedelete = imagedelete;
    }

    public String getModel() {
        return model;
    }
    public void setModel(String model) {
        this.model = model;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }


    public int getImage() {
        return imagedelete;
    }

    public void setImage(int imagedelete) {
        this.imagedelete = imagedelete;
    }


}
