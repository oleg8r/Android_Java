package com.example.university_list;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    RecyclerAdapter recyclerAdapter;
    Toast toast;

    List<Uni> unis = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);

        recyclerView.setAdapter(recyclerAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        fetchUnis();
    }

    private void fetchUnis() {
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET,
                "http://universities.hipolabs.com/search?country=Canada", null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for (int i = 0; i < response.length(); i++) {
                    try {
                        JSONObject jsonObject = response.getJSONObject(i);
                        Uni uni = new Uni(jsonObject.getString("name"), jsonObject.getString("state-province"), getFirstWebPage(jsonObject.getJSONArray("web_pages")));
                        unis.add(uni);

                        recyclerAdapter = new RecyclerAdapter(getApplicationContext(), unis);
                        recyclerView.setAdapter(recyclerAdapter);
                    } catch (JSONException e) {
                        showError(e);
                    }
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError e) {
                        showError(e);
                    }
                });

        Volley.newRequestQueue(this).add(request);
    }

    private String getFirstWebPage(JSONArray jsonArray) throws JSONException {
        if (jsonArray != null && jsonArray.length() > 0) {
            return jsonArray.getString(0);
        }
        return null;
    }

    private void showError(Exception e) {
        unis = new ArrayList<>();
        System.out.println("Error getting data: " + e.getMessage());
        e.printStackTrace();
    }
}