package com.example.university_list;

public class Uni {

    String name;
    String province;
    String webPage;

    public Uni(String name, String province, String webPage) {
        this.name = name;
        this.province = province == null || "null".equals(province) ? "NA" : province;
        this.webPage = webPage == null ? "" : webPage;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getWebPage() {
        return webPage;
    }

    public void setWebPage(String webPage) {
        this.webPage = webPage;
    }
}
