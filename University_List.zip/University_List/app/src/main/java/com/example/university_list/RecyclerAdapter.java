package com.example.university_list;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.MyViewHolder> {

    Context context;
    List<Uni> unis;

    RecyclerAdapter(Context context, List<Uni> unis) {
        this.context = context;
        this.unis = unis;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View convertView = LayoutInflater.from(context).inflate(R.layout.row_layout, parent, false); //convertView is the whole row
        return new MyViewHolder(convertView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.nameView.setText(unis.get(position).getName());
        holder.provinceView.setText(unis.get(position).getProvince());
        holder.pageView.setText(unis.get(position).getWebPage());

    }

    @Override
    public int getItemCount() {
        return unis.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView nameView;
        TextView provinceView;
        TextView pageView;

        public MyViewHolder(@NonNull View view) {
            super(view);
            nameView = view.findViewById(R.id.nameView);
            provinceView = view.findViewById(R.id.provinceView);
            pageView = view.findViewById(R.id.pageView);
        }
    }
}
